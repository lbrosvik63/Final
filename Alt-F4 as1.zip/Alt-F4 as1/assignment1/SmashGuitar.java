package assignment1;

public class SmashGuitar implements Solo
{
	public void playSolo()
	{
		System.out.println("$1,000 down the drain!!!");
	}
	public void displaySolo()
	{
		System.out.println("New solo acquired <<Smash Guitar>>");
	}
}
