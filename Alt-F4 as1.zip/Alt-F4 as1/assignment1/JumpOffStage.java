package assignment1;

public class JumpOffStage implements Solo
{
	public void playSolo()
	{
		System.out.println("Please catch me, PLEASE!!!");
	}
	public void displaySolo()
	{
		System.out.println("New solo acquired <<Jump Off Stage>>");
	}
}
