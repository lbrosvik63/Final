package assignment1;

public class GibsonSG implements Guitar
{
	public void playGuitar()
	{
		System.out.println("Gibson SG, Gibson SG!!! bew bew bew!!!");
	}
	public void displayGuitar()
	{
		System.out.println("Gibson SG equipped, and ready to ROCK!");
	}
}
