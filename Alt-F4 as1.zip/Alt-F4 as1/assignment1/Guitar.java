package assignment1;

public interface Guitar 
{
	public void playGuitar();
	public void displayGuitar();
}
