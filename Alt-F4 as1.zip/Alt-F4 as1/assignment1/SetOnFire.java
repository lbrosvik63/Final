//luke asdf
package assignment1;

public class SetOnFire implements Solo
{
	public void playSolo()
	{
		System.out.println("Burn baby, BURN!!!");
	}
	public void displaySolo()
	{
		System.out.println("New solo acquired <<Set Guitar on Fire>>");
	}
}
