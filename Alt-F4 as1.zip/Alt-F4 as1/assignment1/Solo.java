package assignment1;

public interface Solo 
{
	public void playSolo();
	public void displaySolo();
}
