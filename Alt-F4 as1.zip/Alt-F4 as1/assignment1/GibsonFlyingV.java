package assignment1;

public class GibsonFlyingV implements Guitar
{
	public void playGuitar()
	{
		System.out.println("Flying VEEEEEE!!! bew bew bew");
	}
	public void displayGuitar()
	{
		System.out.println("Gibson Flying V equipped, and ready to ROCK and ROLL!");
	}
}
