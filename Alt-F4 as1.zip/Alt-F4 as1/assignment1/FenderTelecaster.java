package assignment1;

public class FenderTelecaster implements Guitar
{
	public void playGuitar()
	{
		System.out.println("Tele, Tele!!! bew bew bew");
	}
	public void displayGuitar()
	{
		System.out.println("Fender Telecaster tuned up, and ready to ROLL!");
	}
}
