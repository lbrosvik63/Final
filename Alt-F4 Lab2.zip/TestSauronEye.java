//TEAM ALT-F4
//Mark Yevdash
//Luke Brosvik
//Mike Probst
//Lab2

//CSCD454: Design Patterns
//Professor Tom Capaul
//1/16/2014

//This implementation of the observer pattern uses the observable class and observer interface from the java api.
//The EyeOfSauron class extends the observable class, there for is the subject.
//Objects of the BadGuy class implement observer and are automatically registered with EyeOfSauron when they are created. 
//Each time a good guy, hobit, dwarf, elf, or human, is spotted, the number of good guys found is pushed from EyeOfSauron
//	to all the BadGuy objects, the observers, and they display the updated count of each good guy.
//There are methods for finding and losing good guys, so the count can go up and down. If somehow more good guys
//	are lost then there are total good guys, the total number gets set to zero.
    
package assignment2;

public class TestSauronEye {

	public static void main(String[] args) 
	{
        EyeOfSauron eye = new EyeOfSauron();
        BadGuy saruman = new BadGuy(eye, "Saruman");
        BadGuy angmar = new BadGuy(eye, "Angmar");
        
        eye.hobitsFound(1);
        eye.dwarvesFound(14);
        eye.humansFound(5);
        eye.elvesFound(33);
        
        saruman.defeated(); //Saruman is no longer registered with the Eye, only Angmar reports on the enemies
        
        eye.hobitsFound(7);
        eye.elvesFound(78);
        eye.lostDwarves(10);
        eye.lostElves(50);
        eye.lostHobit(200);
        eye.hobitsFound(476);
        
        BadGuy sarumanRez = new BadGuy(eye, "Saruman Resurrected");
        
        eye.elvesFound(6);
        eye.humansFound(95);
        
        sarumanRez.defeated();
        angmar.defeated();
        
        eye.elvesFound(444);//nothing displayed
   	}
}
