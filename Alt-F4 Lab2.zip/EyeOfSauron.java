//TEAM ALT-F4
//Mark Yevdash
//Luke Brosvik
//Mike Probst
//Lab2

package assignment2;

import java.util.Observable;

public class EyeOfSauron extends Observable
{
	private int hobits;
	private int elves;
	private int dwarves;
	private int humans;
	
	public void enemyFound()
	{
		setChanged();  //from Observable class
		notifyObservers();  //pull ???
	}
	public void hobitsFound(int hobitsFound)
	{
		this.hobits = countFound(this.hobits, hobitsFound);
		enemyFound();
	}
	public void elvesFound(int elvesFound)
	{
		this.elves = countFound(this.elves, elvesFound);
		enemyFound();
	}
	public void dwarvesFound(int dwarvesFound)
	{
		this.dwarves = countFound(this.dwarves, dwarvesFound);
		enemyFound();
	}
	public void humansFound(int humansFound)
	{
		this.humans = countFound(this.humans, humansFound);
		enemyFound();
	}
	public void lostHobit(int hobitsLost)
	{
		this.hobits = countLost(this.hobits, hobitsLost);
		enemyFound();
	}
	public void lostElves(int elvesLost)
	{
		this.elves = countLost(this.elves, elvesLost);
		enemyFound();
	}
	public void lostDwarves(int dwarvesLost)
	{
		this.dwarves = countLost(this.dwarves, dwarvesLost);
		enemyFound();
	}
	public void lostHumans(int humansLost)
	{
		this.humans = countLost(this.humans, humansLost);
		enemyFound();
	}
	private int countFound(int total, int found)
	{
		if(found < 1)
			return total;
		else
			return total + found;
	}
	private int countLost(int total, int lost)
	{
		if(total - lost < 0)
			return 0;
		else
			return total - lost;

	}
	public int getHobits()
	{
		return hobits;
	}
	public int getElves()
	{
		return elves;
	}
	public int getDwarves()
	{
		return dwarves;
	}
	public int getHumans()
	{
		return humans;
	}
}
