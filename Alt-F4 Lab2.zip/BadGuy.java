//TEAM ALT-F4
//Mark Yevdash
//Luke Brosvik
//Mike Probst
//Lab2

package assignment2;

import java.util.Observable;
import java.util.Observer;

public class BadGuy implements Observer, DisplayElement 
{
	Observable observable;  //EyeOfSauron eye; //this better than<--
	String name;
	private int hobits;
	private int elves;
	private int dwarves;
	private int humans;
	
	public BadGuy(Observable observable, String name)
	{
		this.observable = observable;
		observable.addObserver(this);
		this.name = name;
	}
	public void update(Observable o, Object arg)//this is pulling the information from EyeOfSauron 
	{
		if(o instanceof EyeOfSauron)
		{
			EyeOfSauron eye = (EyeOfSauron)o;
			this.hobits = eye.getHobits();
			this.elves = eye.getElves();
			this.dwarves = eye.getDwarves();
			this.humans = eye.getHumans();
			display();
		}
	}
	public void defeated()
	{
		observable.deleteObserver(this);
		System.out.println("<<<" + name + " has been defeated>>>");
	}
	public void display()
	{
		System.out.println(name + ": Hobits:" + hobits + " Elves:" + elves + " Dwarves:" + dwarves + " Humans:" + humans);
	}
}
