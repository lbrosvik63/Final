//TEAM ALT-F4
//Mark Yevdash
//Luke Brosvik
//Mike Probst
//Lab2

package assignment2;

public interface DisplayElement 
{
	public void display();
}
